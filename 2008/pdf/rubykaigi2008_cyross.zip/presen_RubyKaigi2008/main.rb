# 
# Miyako Presentation System Version 2.0
#
# 2008 Cyross Makoto
#
require 'Miyako/miyako'
require 'Miyako/idaten_miyako'
require 'Miyako/miyako_ext'
require 'setting'
require 'lib/modules' # ユーティリティモジュール群を組み込み
require 'lib/log_timer'
require 'lib/common'
load 'lib/preset.rb', true # requires.rb の作成

include Miyako

Screen.set_size(800, 600)

require 'tmp/plugins' # 作成した plugins.rb を読み込んで、スライドを組み込み
require 'tmp/requires' # 作成した requires.rb を読み込んで、スライドを組み込み
require 'lib/select_chapter'
require 'lib/slide_nodes'
require 'lib/main_scene'

presen = Story.new
presen.run(MainScene)


class MainScene
  include Miyako::Story::Scene
  include Yuki

  def init
    @com = Common.instance
    init_yuki(@com.selectbox, @com.selectbox, :box)
    titles = Chapters.titles
    chapters = Chapters.startup_chapters
    @commands = Array.new(titles.size){|idx|
      Yuki::Command.new(titles[idx], lambda{true}, idx)
    }
    @com.now_chapter = chapters.clone
    manager = self.manager(self.method(:plot))
    @pr = Miyako::Diagram::Processor.new{|dia|
      dia.add :start,          StartPresen.new(manager)
      dia.add :select_chapter, SelectChapter.new(manager)
      dia.add :show_slide,     ShowSlide.new
      dia.add :end,            EndPresen.new(manager)
      dia.add_arrow(:start, :select_chapter)      {|from|  from.finished? }
      dia.add_arrow(:select_chapter, :end)        {|from|  from.finished? }
      dia.add_arrow(:select_chapter, :show_slide) {|from|  from.show_slide? }
      dia.add_arrow(:show_slide, :start)          {|from|  from.finished? }
      dia.add_arrow(:end, nil)                    {|from|  from.finished? }
    }
    @board = WriteBoard.instance
		font = Font.sans_serif
		font.color = [255,255,255]
		font.size = 20
    @text = Shape.text(:font=>font){
		  text("http://www.twin.ne.jp/~cyross/Miyako/")
			cr
			text("http://www.twin.ne.jp/~cyross/Miyako/Miyako_tutrial.pdf")
		}
		@text.dp = 3000
		@text.right.top
  end

  def setup
    setup_yuki
    @pr.start
    while @pr.finish? do; end
    @board.clear
    @board.show
		@text.show
  end

  def update
    return nil if Input.quit_or_escape?
    @pr.update_input
    return nil if @pr.finish?
    @board.clear if Input.click?(:right)
    pos = Input.get_mouse_position
    if Input.mouse_trigger?(:left)
      @board.draw(pos[:x], pos[:y])
    else
      @board.reset
    end
    @pr.render
    @com.timer.render
    return @now
  end

  def plot
    command @commands, "cansel"
    return nil if result == "cansel" # cansel?
    return result
  end

  def final
		@text.hide
    @board.hide
    @pr.stop
    @com.dispose
  end

  def dispose
		@text.dispose
    @board.dispose
  end
end

module Chapter02
  include Chapter
  
  class Slide01
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("自己")
				cr
				text("紹介")
			}
			self[:text1].centering
      add_arrow_standard_move(:down, Slide02)
		end
  end

  class Slide02
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("サイロス")
				cr
				text("誠")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide01)
      add_arrow_standard_move(:down, Slide0203)
    end
  end

  class Slide0203
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("大阪")
				cr
				text("在住")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide02)
      add_arrow_standard_move(:down, Slide03)
    end
  end

  class Slide03
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("職業")
				cr
				text("プログラマー")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide02)
      add_arrow_standard_move(:down, Slide04)
      add_arrow_standard_move(:left, Slide03a)
    end
  end

  class Slide03a
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("メイン言語")
				cr
				text("Ｃ")
			}
			self[:text1].centering
      add_arrow_standard_move(:right, Slide03)
      add_arrow_standard_move(:down, Slide03b)
    end
  end

  class Slide03b
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("Ｃ＋＋").cr.text("Ｊａｖａ").cr.text("Ｃ＃")
				cr
				text("・・・他の").cr.text("経験アリ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide03a)
      add_arrow_standard_move(:right, Slide03)
    end
  end

  class Slide04
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("趣味")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide03)
      add_arrow_standard_move(:down, Slide05)
    end
  end

  class Slide05
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img1] = Sprite.new(:file=>"image/4koma.jpg", :type=>:as)
			self[:img1].center.top
 
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("四コマ漫画")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:up, Slide04)
      add_arrow_standard_move(:down, Slide06)
    end
  end

  class Slide06
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("Ｆｒｏｍ　")
			  cr	
				text("「まんがライフ」")
			  cr	
				text("Ｔｏ　")
				cr
				text("「まんがタイムきらら」")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide05)
      add_arrow_standard_move(:down, Slide08)
      add_arrow_standard_move(:right, Slide07)
    end
  end

  class Slide07
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("オススメ")
				cr
				text("「ふおんコネクト！」")
				cr
				text("「教官ＡＳＴＲＯ」")
				cr
				text("「棺担ぎのクロ。」")
			}
			self[:text1].centering
      add_arrow_standard_move(:left, Slide06)
    end
  end

  class Slide08
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				"ニコ動"
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text2] = Shape.text(:font=>font, :align=>:center){
				"Nico Nico Douga"
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide06)
      add_arrow_standard_move(:down, Slide09)
      add_arrow_standard_move(:left, Slide08a)
			@sound = Audio::SE.new("sound/nicodou(rin).wav")
    end

		def update
			@sound.play if Input.pushed_any?(:btn1)
		end
  end

  class Slide08a
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("酷道シリーズ")
				cr
				text("（車載カメラ）")
			}
			self[:text1].centering
      add_arrow_standard_move(:right, Slide08)
      add_arrow_standard_move(:down, Slide08b)
    end
  end

  class Slide08b
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("80年代")
				cr
				color(:red){ text("おっさん") }
				cr
				text("ホイホイ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide08a)
      add_arrow_standard_move(:right, Slide08)
    end
  end
 
  class Slide09
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:img1] = Sprite.new(:file=>"image/kotteru.jpg", :type=>:as)
			self[:img1].centering
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("凝っているもの")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:up, Slide08)
      add_arrow_standard_move(:down, Slide10)
    end
  end

  class Slide10
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:img1] = Sprite.new(:file=>"image/miku.png", :type=>:as)
			self[:img1].centering
      add_arrow_standard_move(:up, Slide09)
      add_arrow_standard_move(:down, Slide1001)
    end
  end

  class Slide1001
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("Ｒｕｂｙ歴")
				cr
				text("８年")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide10)
      add_arrow_standard_move(:down, Slide1002)
    end
  end

  class Slide1002
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("代表作")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide1002)
      add_arrow_standard_move(:down, Slide1003)
    end
  end

  class Slide1003
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("Ｍｉｙａｋｏ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide1002)
      add_arrow_standard_move(:down, Slide1004)
    end
  end

  class Slide1004
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("このプレゼン")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide1003)
      add_arrow_standard_move(:down, Slide11)
    end
  end

  class Slide11
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("以下")
				cr
				color(:red){ text("略") }
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide11)
    end
  end

	def self.title; return "自己紹介" end
end

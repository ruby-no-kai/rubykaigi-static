module Chapter04
  include Chapter
  
  class Slide01
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("どうやって？")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("How to make?")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:down, Slide02)
		end
  end

  class Slide02
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("（１）")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide01)
      add_arrow_standard_move(:down, Slide03)
    end
  end

  class Slide03
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("構成を練る")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide02)
      add_arrow_standard_move(:down, Slide04)
    end
  end


  class Slide04
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("（２）")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide03)
      add_arrow_standard_move(:down, Slide05)
    end
  end

  class Slide05
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("パラグラフ")
				cr
				text("を")
				cr
				text("作る")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide04)
      add_arrow_standard_move(:down, Slide06)
    end
  end


  class Slide06
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("（３）")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide05)
      add_arrow_standard_move(:down, Slide07)
    end
  end

  class Slide07
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("シャッフル")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide06)
      add_arrow_standard_move(:down, Slide09)
    end
  end

  class Slide09
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("弱点")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide07)
      add_arrow_standard_move(:down, Slide10)
    end
  end

  class Slide10
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("めんど")
				cr
				text("くさい")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide09)
      add_arrow_standard_move(:down, Slide11)
      add_arrow_standard_move(:right, Slide10a)
    end
  end

  class Slide10a
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("じゃま")
				cr
				text("くさい")
			}
			self[:text1].centering
      add_arrow_standard_move(:left, Slide10)
    end
  end

  class Slide11
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("シャッフル")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide10)
      add_arrow_standard_move(:down, Slide14)
    end
  end

  class Slide13
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("番号")
				cr
				text("固定")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide14)
      add_arrow_standard_move(:down, Slide15)
    end
  end

  class Slide14
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("リンク")
				cr
				text("切れ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide11)
      add_arrow_standard_move(:down, Slide13)
    end
  end

  class Slide15
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("やり直し")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide14)
      add_arrow_standard_move(:down, Slide15x)
    end
  end

  class Slide15x
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("時間")
				cr
				text("の")
				cr
				text("無駄")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide15)
      add_arrow_standard_move(:down, Slide17)
    end
  end

  class Slide17
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				color(:red){ text("そこで") }
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide15x)
      add_arrow_standard_move(:down, Slide18)
    end
  end

  class Slide18
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				color(:dark_red){ text("Ｒｕｂｙ") }
				cr
				text("の")
				cr
				text("出番")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide17)
      add_arrow_standard_move(:down, Slide19)
    end
  end

  class Slide19
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("丸投げ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide18)
      add_arrow_standard_move(:down, Slide20)
    end
  end

  class Slide20
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("パラグラフ")
				cr
				text("＝")
				cr
				text("オブジェクト")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide19)
      add_arrow_standard_move(:down, Slide20x)
    end
  end

  class Slide20x
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("シャッフル")
				cr
				text("制御")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide20)
      add_arrow_standard_move(:down, Slide21)
    end
  end

  class Slide21
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("テキスト")
				cr
				text("ファイル")
				cr
				text("ひとつ")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide20)
      add_arrow_standard_move(:down, Slide22)
    end
  end

  class Slide22
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ＣＳＶ")
				cr
				text("ファイル")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide21)
      add_arrow_standard_move(:down, Slide23)
    end
  end


  class Slide23
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:img] = Sprite.new(:file=>"image/seisakuchu.png", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:up, Slide22)
      add_arrow_standard_move(:down, Slide24)
    end
  end

	
  class Slide24
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("実例")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide23)
      add_arrow_standard_move(:down, Slide25)
    end
  end

	
  class Slide25
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:img] = Sprite.new(:file=>"image/shuffle.png", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:up, Slide24)
      add_arrow_standard_move(:down, Slide26)
    end
  end

  class Slide25x
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("シャッフル")
				cr
				text("を")
				cr
				text("数値化")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide25)
      add_arrow_standard_move(:down, Slide25y)
    end
  end

  class Slide25y
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ゲーム")
				cr
				text("としての")
				cr
				text("ランダム性")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide25x)
      add_arrow_standard_move(:down, Slide26)
    end
  end
			
  class Slide26
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("移動先")
				cr
				text("は")
				cr
				text("ラベル")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide25)
      add_arrow_standard_move(:down, Slide27)
    end
  end
	
  class Slide27
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("可読性")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide26)
      add_arrow_standard_move(:down, Slide28)
    end
  end
	
  class Slide28
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ミス")
				cr
				text("の")
				cr
				text("早期発見")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide27)
      add_arrow_standard_move(:down, Slide29)
    end
  end
	
  class Slide29
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("生産性")
				cr
				text("向上")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide28)
      add_arrow_standard_move(:down, Slide30)
    end
  end
	
  class Slide30
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ロジック")
				cr
				text("に")
				cr
				text("専念")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide29)
      add_arrow_standard_move(:right, Slide31)
    end
  end
	
  class Slide31
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ＩＴ業界")
				cr
				text("の話？")
			}
			self[:text1].centering
      add_arrow_standard_move(:left, Slide30)
    end
  end

	def self.title; return "作り方" end
end

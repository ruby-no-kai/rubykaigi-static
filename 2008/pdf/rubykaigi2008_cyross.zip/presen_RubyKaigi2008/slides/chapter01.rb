module Chapter01
  include Chapter
  
  class Slide01
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			font = DefaultFont.get
			font.use_shadow = true
      self[:text1] = Shape.takahashi(:font=>font, :size=>[640,480], :align=>:center){
        text("Ｒｕｂｙで")
        cr
        text("ゲームブックを")
        cr
        text("作ってみよう！")
      }
      self[:text1].centering
      self[:text1e] = Shape.text(:font=>font.property{|fn| fn.size = 24}){
        "Let's create interactive gamebook!"
      }
      self[:text1e].center.bottom{|body| 10.percent(body) }
      self[:text2] = Shape.text(:font=>font.property{|fn| fn.size = 16}){
        "2008.06.22 Cyross Makoto"
      }
      self[:text2].center.bottom
#      add_arrow(:down, Slide01)
			font.use_shadow = false
    end
  end
  def self.title; return "タイトル" end
end


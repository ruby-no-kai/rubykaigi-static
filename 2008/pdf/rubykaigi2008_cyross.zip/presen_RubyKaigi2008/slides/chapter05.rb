module Chapter05
  include Chapter
  
  class Slide01
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("デジタルも")
				cr
				text("いいけど")
				cr
				text("アナログ")
				cr
				text("もね")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("We can play digital game, but we can also play analog game!")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:down, Slide08)
      add_arrow_ex(:event=>:down, :slide=>Slide03, :trigger=>TimerTrigger.new(5.0))
		end
  end

  class Slide02
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ご静聴")
				cr
				text("ありがとう")
				cr
				text("ございました")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Thank you very much!")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide01)
      add_arrow_standard_move(:down, Slide03)
    end
  end

  class Slide03
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				color(:red){ text("特報") }
				
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("hot news!")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up,   Slide02)
      add_arrow_standard_move(:down, Slide06)
      add_arrow_ex(:event=>:down, :slide=>Slide06, :trigger=>TimerTrigger.new(5.0))
    end
  end

  class Slide06
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("コミック").cr.text("マーケット").cr
				text("７４").cr.text("出展！")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("I can make a presentation at Comic Market 74!")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide03)
      add_arrow_standard_move(:down, Slide07)
      add_arrow_ex(:event=>:down, :slide=>Slide07, :trigger=>TimerTrigger.new(5.0))
    end
  end

  class Slide07
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("８／１６")
				cr
				text("東メ－０５ａ")
				cr
				text("＠東京ビッグサイト")
		  }
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("（２００８／６／２２現在の話）")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide06)
      add_arrow_standard_move(:down, Slide08)
    end
  end

  class Slide08
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("最後に")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("at last / enfin(French)")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide01)
      add_arrow_standard_move(:down, Slide09)
    end
  end

   class Slide09
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:img] = Sprite.new(:file=>"image/ruby15th.png", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:up, Slide08)
      add_arrow_standard_move(:down, Slide02)
    end
  end

   def self.title; return "まとめ" end
end

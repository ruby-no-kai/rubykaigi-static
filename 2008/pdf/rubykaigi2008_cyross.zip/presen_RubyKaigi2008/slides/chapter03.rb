module Chapter03
  include Chapter
  
  class Slide01
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=32; obj.color=Color[:black]}
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ゲームブック")
				cr
				text("って")
				cr
				text("何？")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("What is interactive game book?")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:down, Slide02)
		end
  end

  class Slide02
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("実例")
			}
			self[:text1].centering
      add_arrow_standard_move(:up, Slide01)
      add_arrow_standard_move(:down, Slide03)
    end
  end

  class Slide03
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
			self[:img1] = Sprite.new(:file=>"image/hotel.jpg", :type=>:as)
			self[:img1].center.top
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［１］　君は筑波のとあるホテルに居る。")
				cr
				text("←部屋をあさってみる（２へ）")
				text("→椅子にふんぞり返ってみる（３へ）")
				cr
				text("↓とりあえず踊ってみる（１４へ）")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:up, Slide02)
      add_arrow_standard_move(:down, Slide04)
      add_arrow_standard_move(:left, Slide03a1)
      add_arrow_standard_move(:right, Slide03a2)
    end
  end

  class Slide03a1
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img1] = Sprite.new(:file=>"image/negi.png", :type=>:as)
			self[:img1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［２］　ネギを見つけた。")
				cr
				text("　→５へ")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:down, Slide03b1)
    end
  end

  class Slide03a2
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img1] = Sprite.new(:file=>"image/funzori.jpg", :type=>:as)
			self[:img1].center.top
      font = Font.sans_serif.property{|obj| obj.size=20; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［３］　とりあえずふんぞり返ってみたら、")
				text("　日が暮れた。")
				cr
				text("　→５へ")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:down, Slide03b1)
    end
  end

  class Slide03b1
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img1] = Sprite.new(:file=>"image/hotel2.jpg", :type=>:as)
			self[:img1].center.top
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［５］　部屋を出てみると、見知らぬ影が居た。")
				cr
				text("←攻撃してみる（６へ）　")
				text("→近づいてみる（７へ）")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:left,  Slide03b3)
      add_arrow_standard_move(:right, Slide03b2)
    end
  end

  class Slide03b2
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［７］何が起きたかは分からないけど、とりあえず")
				cr
				text("ゲームオーバー！")
			}
			self[:text1].centering
      add_arrow_standard_move(:down,  Slide05)
    end
  end

  class Slide03b3
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img1] = Sprite.new(:file=>"image/baar.png", :type=>:as)
			self[:img1].center.top
       font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［６］　君の手にある「バールのようなもの」を")
				cr
				text("振りかざし、敵を倒した！i　")
				text("おめでとう！")
			}
			self[:text1].center.bottom
      add_arrow_standard_move(:down,  Slide05)
    end
  end

  class Slide04
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
      self[:text1] = Shape.text(:font=>font, :align=>:center){
				text("［１４］　一心不乱に踊っていたら、").cr
				text("従業員に通報されて逮捕されてしまった。").cr
				text("ゲームオーバー！")
			}
			self[:text1].centering
      add_arrow_standard_move(:down, Slide05)
    end
  end

  class Slide05
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("選択肢付")
				cr
				text("書籍")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Book of selectable paragraphs")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up,   Slide02)
      add_arrow_standard_move(:down, Slide06)
    end
  end

  class Slide06
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("１９８０").cr.text("年代")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("1980s")
			}
			self[:text2].center.bottom
       add_arrow_standard_move(:up, Slide05)
      add_arrow_standard_move(:down, Slide07)
    end
  end

  class Slide07
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("ピック")
				cr
				text("アップ")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Pick up")
			}
			self[:text2].center.bottom
       add_arrow_standard_move(:up, Slide06)
      add_arrow_standard_move(:down, Slide08)
      add_arrow_standard_move(:left, Slide07a)
    end
  end

  class Slide07a
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img] = Sprite.new(:file=>"image/druaga.jpg", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:down, Slide07b)
      add_arrow_standard_move(:right, Slide07a)
    end
  end

  class Slide07b
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img] = Sprite.new(:file=>"image/sorcery1.jpg", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:up, Slide07a)
      add_arrow_standard_move(:down, Slide07c)
      add_arrow_standard_move(:right, Slide07b2)
    end
  end

  class Slide07b2
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img] = Sprite.new(:file=>"image/sorcery2.jpg", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:left,  Slide07b)
      add_arrow_standard_move(:right, Slide07b3)
    end
  end

  class Slide07b3
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("浅羽さや子").cr.text("さんの").cr.text("遺作")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Sayako Asaba's last work")
			}
			self[:text2].center.bottom
       add_arrow_standard_move(:left,  Slide07b)
      add_arrow_standard_move(:right, Slide07)
    end
  end

  class Slide07c
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img] = Sprite.new(:file=>"image/lostworld.jpg", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:up,    Slide07b)
      add_arrow_standard_move(:down,  Slide08)
      add_arrow_standard_move(:right, Slide07c2)
    end
  end

  class Slide07c2
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
			self[:img] = Sprite.new(:file=>"image/queensblade.jpg", :type=>:as)
			self[:img].centering
      add_arrow_standard_move(:left,  Slide07c)
      add_arrow_standard_move(:right, Slide07)
    end
  end

  class Slide08
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				"愛好者"
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Fans")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide07)
      add_arrow_standard_move(:down, Slide09)
    end
  end

  class Slide09
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("同人誌")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Dojinshi")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up, Slide08)
      add_arrow_standard_move(:down, Slide10)
    end
  end
 
  class Slide10
    include MPSSlide
    
    def initialize
      init(Slide["640x480"])
      self[:text1] = Shape.takahashi(:font=>DefaultFont.get, :size=>[640,480], :align=>:center){
				text("コミック")
				cr
				text("マーケット")
			}
			self[:text1].centering
      font = Font.sans_serif.property{|obj| obj.size=24; obj.color=Color[:black]}
	    self[:text2] = Shape.text(:font=>font, :align=>:center){
				text("Comic Market")
			}
			self[:text2].center.bottom
      add_arrow_standard_move(:up,   Slide09)
    end
  end

  def self.title; return "ゲームブックって？" end
end

require 'singleton'

class WritePen
  def initialize(color=[255,0,0])
    @color = color
    @org_pos = [-1,-1]
  end

  def draw(sprite, x, y)
    @org_pos = [x, y] if @org_pos == [-1,-1]
    sprite.draw_line(@org_pos << x <<  y, @color)
    @org_pos = [x, y]
  end

  def reset
    @org_pos = [-1, -1]
  end
end

class WriteBoard
  include Singleton

  def initialize(color = [255,0,0])
    @board = Sprite.new(:size=>[Screen.w, Screen.h], :type=>:ac).property{|b| b.dp = 1000}
    @pen = WritePen.new(color)
  end

  def show
    @board.show
  end

  def hide
    @board.hide
  end

  def draw(x, y)
    @pen.draw(@board, x, y)
  end

  def move(x, y)
    @pen.move(x, y)
  end

  def reset
    @pen.reset
  end

  def clear
    @board.fill([0,0,0,0])
  end
  
  def dispose
    @board.dispose
    @board = nil
  end
end

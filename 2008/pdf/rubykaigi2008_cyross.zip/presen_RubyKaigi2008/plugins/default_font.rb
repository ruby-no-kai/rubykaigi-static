require 'singleton'

class DefaultFont
  include Singleton
  def DefaultFont.get
    return Font.sans_serif.property{|f| f.color=Color[:black]}
  end
end

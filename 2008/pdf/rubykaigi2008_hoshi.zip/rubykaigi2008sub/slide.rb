require "rss/2.0"
require "open-uri"
require "news"

TextLine = Struct.new(:text, :font, :color)

class Slide

  @@tmp_val = nil

  def self.news
    @@news ||= News.new
  end

  @@news_visible = false
  def self.news_visible?
    @@news_visible
  end

  def self.tmp_val
    @@tmp_val
  end

  def self.tmp_val=(val)
    @@tmp_val = val
  end

  def self.fonts
    @@fonts ||= {
      :small       => Font.new("fonts/M+1P+IPAG circle", 20),
      :small2      => Font.new("fonts/M+1P+IPAG circle", 20),
      :normal      => Font.new("fonts/M+1P+IPAG circle", 24),
      :normal_bold => Font.new("fonts/M+1P+IPAG circle", 32),
      :big         => Font.new("fonts/M+1P+IPAG circle", 32),
      :big2        => Font.new("fonts/M+1P+IPAG circle", 32),
      :mono        => Font.new("fonts/M+1VM+IPAG circle", 20),
    }
  end

  attr_reader :content_str
  attr_reader :pre_proc
  attr_reader :post_proc
  attr_accessor :centering

  def self.background_color
    @@background_color ||= Color.new(0xee, 0xee, 0xff)
  end
  
  def initialize(content_str, options = {}, &block)
    @content_str = content_str
    @pre_proc = block if block_given?
    @post_proc = options[:post_proc]
    @centering = options[:centering] || false
    @vx = options[:vx] || 0
    @vy = options[:vy] || 0
  end

  def content
    @content ||= parse_content(content_str.strip)
  end

  def render_background_at(s)
    (s.height / 4).times do |i|
      rate = i.quo(s.height / 4)
      red   = 0 # (0xcc * (1 - rate) + 0x99 * rate).to_i
      green = 0 # (0xcc * (1 - rate) + 0x99 * rate).to_i
      blue  = (0x66 * (1 - rate) + 0x00 * rate).to_i
      s.fill_rect(0, i * 4, s.width, 4, Color.new(red, green, blue))
    end
  end

  def update(s, index, count)
    @@news_visible = !@@news_visible if Input.keys(:keyboard, :duration => 1).include?(:d1)
    Slide.news.update(s) if Slide.news_visible?
    s.clear
    render_background_at(s)
    pre_proc.call(s) if pre_proc
    width, height = content_size
    if text_texture
      x = (s.width - content_size[0]) / 2 + @vx
      y = centering ? (s.height - content_size[1]) / 2 : 32 + @vy
      s.render_texture(text_texture, x, y)
=begin
      s.render_in_perspective(text_texture,
      :camera_x => text_texture.width / 2,
      :camera_y => text_texture.height * 2,
                              :camera_height => 50,
                              :intersection_x => s.width / 2,
                              :intersection_y => s.height / 2)
=end
    end
=begin
    # footer
    font = Slide.fonts[:small]
    color = Color.new(0x99, 0x99, 0xff)
    footer_texture = Texture.new(s.width, 48)
    footer1 = "RubyKaigi 2008"
    footer_texture.render_text(footer1, 24, 0, font, color, true)
    footer2 = "(#{index + 1}/#{count})"
    x = footer_texture.width - font.get_size(footer2)[0] - 20
    footer_texture.render_text(footer2, x, 0, font, color, true)
    s.render_texture(footer_texture, 0, s.height - footer_texture.height)
=end
    # post proc
    post_proc.call(s) if post_proc
    # news
    Slide.news.render_news_at(s) if Slide.news_visible?
    # controller
    keys = Input.keys(:keyboard, :duration => 1)
    if keys.include?(:right) or keys.include?(:enter)
      Slide.tmp_val = nil
      [index + 1, count - 1].min
    elsif keys.include?(:left)
      Slide.tmp_val = nil
      [index - 1, 0].max
    else
      index
    end
  end

  private

  def content_size
    @content_size ||=
      (content.inject([0, 0]) do |size, line|
         new_size = Slide.fonts[line.font].get_size(line.text)
         scale = case line.font
                 when :big2; 1
                 else;       1
                 end
         new_size = new_size.map{|i| i * scale}
         [[size[0], new_size[0]].max, size[1] + new_size[1] * 1.5]
       end)
  end

  def text_texture
    @text_texture ||=
      (width, height = content_size
       if 0 < width and 0 < height
         text_texture = Texture.new(width, height)
         content.inject(0) do |y, line|
           font = Slide.fonts[line.font]
           line_width, line_height = font.get_size(line.text)
           case line.font
           when :big2
             scale_x = scale_y = 1
           else
             scale_x = scale_y = 1
           end
           if 0 < line_width
             tmp_texture = Texture.new(line_width, line_height)
             # shadow
             case line.font
             when :big, :big2
               tmp_texture.render_text(line.text, 2, 2, font, Color.new(0x66, 0x66, 0x66, 128), true)
             end
             tmp_texture.render_text(line.text, 0, 0, font, line.color, true)
             text_texture.render_texture(tmp_texture, 0, y, :scale_x => scale_x, :scale_y => scale_y)
           end
           y + font.size * scale_y * 1.5
         end
         text_texture
       else
         nil
       end)
  end

  def parse_content(content_str)
    in_code = false
    default_color = current_color = Color.new(0xff, 0xff, 0xff)
    content_str.inject([]) do |content, line|
      case line
      when /^@code_start/
        in_code = true
      when /^@code_end/
        in_code = false
      when /^@color back$/
        current_color = default_color
      when /^@color (.+)$/
        current_color = eval($1)
      when /^@em /
        text  = line[4, line.length].chomp
        font  = :normal_bold
        color = Color.new(0xcc, 0xcc, 0x99)
      when /^\s*!!!/
        text  = line.sub(/!!!/, "").chomp
        font  = :big2
        color = Color.new(0xff, 0x99, 0x99)
      when /^\s*!!/
        text  = line.sub(/!!/, "").chomp
        font  = :big2
        color = Color.new(0xcc, 0xcc, 0xcc)
      when /^\s*!/
        text  = line.sub(/!/, "").chomp
        font  = :big
        color = Color.new(0xcc, 0xcc, 0xff)
      when /^__/
        text  = line[2, line.length].chomp
        font  = :small
        color = current_color
      when /^_/
        text  = line[1, line.length].chomp
        font  = :small2
        color = current_color
      else
        text  = line.chomp
        font  = :normal
        color = current_color
      end
      if text
        if in_code
          content << TextLine.new(text, :mono, color)
        else
          content << TextLine.new(text, font, color)
        end
      else
        content
      end
    end
  end

end

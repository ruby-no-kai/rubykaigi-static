require "starruby"
include StarRuby

require "slide"
require "slides"

$KCODE = 'u'

slide_index = ARGV[0] ? [ARGV[0].to_i - 1, 0].max : 0

if ARGV[0] == "files"
  Slides.size.times do |i|
    slide = Slides[i]
    texture = Texture.new(640, 480)
    slide.update(texture, i + 1, Slides.size)
    texture.save("slides/#{i+1}.png")
  end
else
  begin
    Game.title = "RubyKaigi 2008"
    Game.run(640, 480,
             :fullscreen => ARGV[1] == "f",
             :window_scale => 1,
             :cursor => true) do
      Game.title = Game.real_fps.to_s
      slide_index = Slides[slide_index].update(Game.screen, slide_index, Slides.size)
      Game.terminate if Input.keys(:keyboard, :duration => 1).include?(:escape)
    end
  ensure
    puts slide_index + 1
  end
end

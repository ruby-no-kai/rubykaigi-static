require "starruby"

module RubyBuster
  class Controller

    include StarRuby

    attr_reader :model

    def initialize(model)
      @model = model
    end

    def update
      StarRuby::Game.terminate if Input.keys(:keyboard).include?(:escape)
      model.update
      send("update_#{model.state}")
    end
    
    def update_init
      model.start if Input.keys(:mouse, :duration => 1).include?(:left)
    end

    def update_playing
      x, y = Input.mouse_location
      if Input.keys(:mouse, :duration => 1).include?(:left)
        model.try_get(x, y)
      end
      if model.gameover?(x, y)
        model.gameover
      end
    end

    def update_gameover
      @gameover_counter ||= 20
      @gameover_counter -= 1 if 0 < @gameover_counter
      if @gameover_counter <= 0 and
          Input.keys(:mouse, :duration => 1).include?(:left)
        model.init
        @gameover_counter = nil
      end
    end

  end
end

require "starruby"

module RubyBuster
  class View

    include StarRuby

    attr_reader :model
    attr_reader :font

    def initialize(model)
      @model = model
      @font = Font.new("fonts/M+1P+IPAG circle", 18)
      @enemy_textures = {
        :ruby => Texture.load("images/ruby"),  
        # :perl => Texture.load("images/perl"),
      }
      @explosion_texture = Texture.load("images/explosion")
    end

    def update(screen)
      screen.clear
      # enemies
      model.enemies.each do |enemy|
        rate = 1 - enemy.life.quo(enemy.max_life)
        screen.render_texture(@enemy_textures[enemy.type], enemy.x, enemy.y,
                              :tone_red => 0xff * rate,
                              :tone_green => 0xff * rate,
                              :tone_blue => 0x66 * rate,
                              # :angle => ((rate ** 2) / 2) * 2 * Math::PI * 50,
                              :center_x => enemy.width / 2,
                              :center_y => enemy.height / 2)
      end
      # explosions
      model.explosions.each do |explosion|
        index = 16 - explosion.life
        screen.render_texture(@explosion_texture, explosion.x, explosion.y,
                              :src_x => (index % 8) * explosion.width,
                              :src_y => (index / 8) * explosion.height,
                              :src_width => explosion.width,
                              :src_height => explosion.height)
      end
      if model.state == :gameover
        screen.render_rect(0, 0, screen.width, screen.height,
                           Color.new(128, 128, 128, 128))
      end
      case model.state
      when :init, :gameover
        str = {
          :init     => "Click to start!",
          :gameover => "Gameover!!"
        }[model.state]
        width, height = font.get_size(str)
        x, y = (screen.width - width) / 2, (screen.height - height) / 2
        screen.render_text(str, x, y, font, Color.new(0xff, 0xff, 0xff), true)
      end
      # score
      screen.render_text("#{model.score}", 16, 16, font, Color.new(0xff, 0xff, 0xff), true)        
    end

  end
end

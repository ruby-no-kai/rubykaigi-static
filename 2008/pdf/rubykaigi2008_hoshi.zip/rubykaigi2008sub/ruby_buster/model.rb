module RubyBuster
  class Model

    attr_reader :state
    attr_reader :enemies
    attr_reader :explosions
    attr_reader :score

    def initialize
      init
    end

    def init
      @state = :init
      @score = 0
      @enemies = []
      @explosions = []
    end

    def start
      @state = :playing
      @enemies = [Enemy.new(Enemy.types[rand(Enemy.types.size)],
                            rand(640 - 49), rand(480 - 49))]
      @explosions = []
    end

    def try_get(x, y)
      if enemy = @enemies.reverse.find do |enemy|
          (enemy.x <= x) and (x < enemy.x + enemy.width) and
            (enemy.y <= y) and (y < enemy.y + enemy.height)
        end
        @score += enemy.score
        @enemies.delete(enemy)
      end
    end

    def update
      if state == :playing
        @enemies.dup.each do |enemy|
          enemy.update
          if enemy.dead?
            @enemies.delete(enemy)
            @explosions << Explosion.new(enemy)
          end
        end
        @explosions.dup.each do |explosion|
          explosion.update
          @explosions.delete(explosion) if explosion.dead?
        end
        if @enemies.size < 100 and rand(10) == 0
          @enemies << Enemy.new(Enemy.types[rand(Enemy.types.size)],
                                rand(640 - 49), rand(480 - 49))
        end
      end
    end

    def gameover?(x, y)
      !!(@explosions.find do |ex|
           (ex.x + 10 <= x) and (x < ex.x + ex.width - 10) and
            (ex.y + 10 <= y) and (y < ex.y + ex.height - 10)
         end)
    end

    def gameover
      @state = :gameover
    end

    class Enemy

      def self.types
        @types ||= [:ruby] #, :perl]
      end

      attr_reader :type
      attr_reader :x
      attr_reader :y
      attr_reader :life
      attr_reader :max_life

      def initialize(type, x, y)
        @type = type
        @x = x
        @y = y
        @life = @max_life = {:ruby => 150, :perl => 150}[type]
      end

      def width
        49
      end

      def height
        49
      end

      def score
        (@max_life - @life) * 100
      end

      def dead?
        @life == 0
      end

      def update
        @life -= 1 if 0 < @life
      end

    end

    class Explosion

      attr_reader :x
      attr_reader :y
      attr_reader :life
      
      def initialize(enemy)
        @x = enemy.x + enemy.width / 2 - width / 2
        @y = enemy.y + enemy.height / 2 - height / 2
        @life = 16
      end

      def width
        96
      end

      def height
        96
      end

      def update
        @life -= 1 unless dead?
      end

      def dead?
        @life <= 0
      end

    end

  end
end

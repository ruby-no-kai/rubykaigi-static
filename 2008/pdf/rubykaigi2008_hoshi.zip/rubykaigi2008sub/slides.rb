require "slide"
require "ruby_buster"

module Slides

  @@slides = []

  def self.[](index)
    @@slides[index]
  end

  def self.size
    @@slides.size
  end

  def self.render_table_at(s, table, ox, oy, line_height_rate)
    font = Slide.fonts[:small]
    (table + [nil]).each_with_index do |data, i|
      x, y = ox, i * font.size * line_height_rate + oy
      s.render_line(x, y, s.width - x, y, Color.new(0x99, 0x99, 0x99))
      next unless data
      s.render_text(data[0], x + 8, y + 8, font, Color.new(0xff, 0xff, 0xff), true)
      data[1].split("\n").each_with_index do |line, j|
        s.render_text(line, x + 200, y + 8 + j * font.size * 1.5, font, Color.new(0xff, 0xff, 0x99), true)
      end
    end
  end

  @@slides << Slide.new(%Q{
!!!Ruby のゲーム開発の現状 &
!!!自作ゲームライブラリ Star Ruby

東京大学大学院
星一}, :centering => true)

  @@slides << Slide.new(%Q{
!話すこと

* 自己紹介
* Ruby のゲーム開発の現状
* 自作ゲームライブラリ Star Ruby
})

  @@slides << Slide.new(%Q{
!自己紹介

名前:
  星一 (hajimehoshi)

所属:
  東京大学大学院 創造情報学専攻 修士 2 年

趣味:
  ニコニコ動画を見ること
})

  @@slides << Slide.new(%Q{
!今までやったこと

* Ruby の拡張ライブラリを C# で書く試み
  (るびま第 21 号参照)
* スーファミ筐体 Ruby マシン
  (停止中)
})

  libraries = {:name => ""}

  @@slides << Slide.new(%Q{
!!!Ruby によるゲーム開発の現状
}, :centering => true)

  @@slides << Slide.new(%Q{
!Ruby で作られたゲームなんてあるの?

@em あるよ
})

  @@slides << Slide.new(%Q{
!ライブラリはあるの?
}) do |s|
    table = [["DirectX",  "D4R, RGSS/RGSS2, ..."],
             ["SDL",      "Ruby/SDL, RubyGame, RSDL,\ngosu, Star Ruby, ..."],
             ["Ruby/SDL", "MyGame, Miyako, ..."],
             ["OpenGL",   "ruby-opengl, G3DRuby, ODE,\n..."]]
    render_table_at(s, table, 64, 96, 4)
  end

  @@slides << Slide.new(%Q{
!Ruby で作られたゲーム紹介
}, :centering => true)

  azatosu_texture = Texture.load("images/azatosu")
  @@slides << Slide.new(%Q{
!字祷子D

株式会社 Nitoro+
Ruby/SDL 製
Ruby スクリプトは
暗号化
}, :vx => -160 ) do |s|
    x = (s.width - azatosu_texture.width) - 32
    y = s.height - azatosu_texture.height - 54
    s.render_texture(azatosu_texture, x, y)
  end

  rpgvx_texture = Texture.load("images/rpgvx")
  @@slides << Slide.new(%Q{
!RPG ツクール XP/VX

株式会社エンターブレイン
}) do |s|
    x = (s.width - rpgvx_texture.width) / 2
    y = s.height - rpgvx_texture.height - 54
    s.render_texture(rpgvx_texture, x, y)
  end

  rpgvx_scripts_texture = Texture.load("images/rpgvx_scripts")
  @@slides << Slide.new(%Q{
!RPG ツクール XP/VX

RGSS
(Ruby +
ゲーム用 Lib.)

RPG のロジッ
クが RGSS で
書かれている
}, :vx => -96) do |s|
    x = (s.width - rpgvx_scripts_texture.width) - 32
    y = s.height - rpgvx_scripts_texture.height - 54
    s.render_texture(rpgvx_scripts_texture, x, y)
  end

  nario_texture = Texture.load("images/nario")
  @@slides << Slide.new(%Q{
!Ruby でマリオ

authorNari さん
Ruby/SDL 製
}) do |s|
    x = (s.width - nario_texture.width) / 2
    y = s.height - nario_texture.height - 54
    s.render_texture(nario_texture, x, y)
  end

  @@slides << Slide.new(%Q{
!(遅く|重く)ないの?

@em (遅い|重い)よ

個人的には楽観視
_今後のハードウェアの発展に期待
})

  @@slides << Slide.new(%Q{
!GC はどうなの?

@em 問題になりえるよ

CRuby の GC の実装はよくないらしい
_authorNari さんがなんとかしてくれるでしょう

実際のゲームで困るかは未知数
})

  @@slides << Slide.new(%Q{
!Ruby でゲームを作るのは楽しいの?

@em 楽しいよ

メモリ管理とか気にしなくてよいのがいい
プログラミング学習に最適では
})

  @@slides << Slide.new(%Q{
Ruby のゲーム開発はとてもよさそうだ
}, :centering => true)

  @@slides << Slide.new(%Q{
Ruby のゲーム開発はとてもよさそうだ

@em だがしかし
}, :centering => true)

  @@slides << Slide.new(%Q{
Ruby のゲーム開発はとてもよさそうだ

@em だがしかし

他の言語に比べてまだまだ例が少ない
}, :centering => true)

  @@slides << Slide.new(%Q{
!他の LL ではどうなの?

@em PyGame のゲームはたくさん
  数百件規模

@em HSP のゲームもたくさん
})

  @@slides << Slide.new(%Q{
!なんで流行らないの?

よくわからないが多分
@em 流行ってないから流行らない

* コミュニティがない
* ノウハウがない
})

  @@slides << Slide.new(%Q{
!流行らせるためには

* コミュニティを作ろう
* ノウハウをためよう

誰か一緒にやりませんか?
})

  @@slides << Slide.new(%Q{
!まとめ

* Ruby でゲームは十分作れます
* まだまだコミュニティとノウハウがない
* これから盛り上げていきたいな
})

  @@slides << Slide.new(%Q{
!!!Ruby によるゲーム開発
!!!おわり
}, :centering => true)

  @@slides << Slide.new(%Q{
!!!自作ゲームライブラリ
!!!Star Ruby
}, :centering => true)

  @@slides << Slide.new(%Q{
!Star Ruby ってなに

スーファミっぽいゲームを
誰でも簡単に作るためのライブラリ

_別にスーファミっぽくなくても
_2D ゲームならなんでも作れる

@code_start
_http://www.starruby.info/
@code_end
})

  sample_texture = Texture.load("images/sample")
  sample_x = 0
  sample_y = 0
  sample_scale_px = 0
  sample_scale_py = 0
  sample_angle = 0
  @@slides << Slide.new(%Q{
!画像の描画 (1)
}) do |s|
    keys = Input.keys(:keyboard)
    if keys.include?(:w)
      sample_scale_py += 1
    elsif keys.include?(:z)
      sample_scale_py -= 1
    end
    if keys.include?(:a)
      sample_scale_px -= 1
    elsif keys.include?(:s)
      sample_scale_px += 1
    end
    if keys.include?(:x)
      sample_angle -= 2
    elsif keys.include?(:v)
      sample_angle += 2
    end
    if keys.include?(:r)
      sample_y -= 2
    elsif keys.include?(:c)
      sample_y += 2
    end
    if keys.include?(:d)
      sample_x -= 2
    elsif keys.include?(:f)
      sample_x += 2
    end
    x = (s.width - sample_texture.width) / 2
    y = (s.height - sample_texture.height) - 54
    s.render_texture(sample_texture, sample_x, sample_y,
                     :scale_x => 1.05 ** sample_scale_px,
                     :scale_y => 1.05 ** sample_scale_py,
                     :angle => sample_angle.degrees)
                     #:center_x => sample_texture.width / 2,
                     #:center_y => sample_texture.height / 2)
    # s.render_rect(0, 0, s.width, s.height, Color.new(0, 0, 0, 0xcc))
    codes = %Q{
require "starruby"
include StarRuby

texture =
  Texture.load("images/ranranru")
Game.run(640, 480) do
  s = Game.screen
  s.clear
  s.render_texture(texture, #{sample_x}, #{sample_y}}
    if sample_scale_px != 0
      codes << ",\n    :scale_x => %0.2f" % (1.05 ** sample_scale_px)
    end
    if sample_scale_py != 0
      codes << ",\n    :scale_y => %0.2f" % (1.05 ** sample_scale_py)
    end
    if sample_angle != 0
      codes << ",\n    :angle => #{sample_angle}.degrees"
    end
    codes << ")\nend"
    y = 80
    codes.split("\n").each do |line|
      s.render_text(line, 250, y,
                    Slide.fonts[:mono], Color.new(0xcc, 0xcc, 0x99), true)
      y += Slide.fonts[:mono].size + 4
    end
  end

  sample_texture2 = Texture.load("images/sample2")
  sample_tone_red   = 0
  sample_tone_green = 0
  sample_tone_blue  = 0
  sample_saturation = 255
  @@slides << Slide.new(%Q{
!画像の描画 (2)
}) do |s|
    keys = Input.keys(:keyboard)
    if keys.include?(:q)
      sample_tone_red = [sample_tone_red - 4, -255].max
    elsif keys.include?(:w)
      sample_tone_red = [sample_tone_red + 4, 255].min
    end
    if keys.include?(:a)
      sample_tone_green = [sample_tone_green - 4, -255].max
    elsif keys.include?(:s)
      sample_tone_green = [sample_tone_green + 4, 255].min
    end
    if keys.include?(:z)
      sample_tone_blue = [sample_tone_blue - 4, -255].max
    elsif keys.include?(:x)
      sample_tone_blue = [sample_tone_blue + 4, 255].min
    end
    if keys.include?(:c)
      sample_saturation = [sample_saturation - 4, 0].max
    elsif keys.include?(:v)
      sample_saturation = [sample_saturation + 4, 255].min
    end
    # x = (s.width - sample_texture.width) / 2
    # y = (s.height - sample_texture.height) - 54
    s.render_texture(sample_texture2, 0, 0,
                     #:scale_x => 1.05 ** sample_scale_px,
                     #:scale_y => 1.05 ** sample_scale_py,
                     #:angle => sample_angle.degrees,
                     #:center_x => sample_texture.width / 2,
                     #:center_y => sample_texture.height / 2,
                     :tone_red => sample_tone_red,
                     :tone_green => sample_tone_green,
                     :tone_blue => sample_tone_blue,
                     :saturation => sample_saturation)
        codes = %Q{
require "starruby"
include StarRuby

texture =
  Texture.load("images/ranranru2")
Game.run(640, 480) do
  s = Game.screen
  s.clear
  s.render_texture(texture, 0, 0}
    if sample_tone_red != 0
      codes << ",\n    :tone_red => #{sample_tone_red}"
    end
    if sample_tone_green != 0
      codes << ",\n    :tone_green => #{sample_tone_green}"
    end
    if sample_tone_blue != 0
      codes << ",\n    :tone_blue => #{sample_tone_blue}"
    end
    if sample_saturation != 255
      codes << ",\n    :saturation => #{sample_saturation}"
    end
    codes << ")\nend"
    y = 80
    codes.split("\n").each do |line|
      s.render_text(line, 250, y,
                    Slide.fonts[:mono], Color.new(0xcc, 0xcc, 0x99), true)
      y += Slide.fonts[:mono].size + 4
    end
  end

  camera_yaw = 0
  camera_pitch = -90
  blur_loop = false  
  perspective_proc = proc do |s|
    keys = Input.keys(:keyboard)
    if keys.include?(:w)
      camera_pitch += 1
    elsif keys.include?(:z)
      camera_pitch -= 1
    end
    if keys.include?(:a)
      camera_yaw -= 1
    elsif keys.include?(:s)
      camera_yaw += 1
    end
    blur_loop = !blur_loop if Input.keys(:keyboard, :duration => 1).include?(:q)
    s2 = s.dup
    s.clear
    s.render_in_perspective(s2,
                            :camera_x => s.width / 2,
                            :camera_y => s.height * 3 + (camera_pitch.quo(90) * s.height * 2.5),
                            :camera_height => 500,
                            :camera_yaw => camera_yaw.degrees,
                            :camera_pitch => camera_pitch.degrees,
                            :intersection_x => s.width / 2,
                            :intersection_y => s.height * 3 / 4,
                            :blur => :background,
                            :loop => blur_loop)
  end
  @@slides << Slide.new(%Q{
!透視変換ができる

マリオカートとか F-ZERO とか
}, :post_proc => perspective_proc)

  @@slides << Slide.new("", :post_proc => perspective_proc) do |s|
    scale_x = s.width.quo(sample_texture.width)
    scale_y = s.height.quo(sample_texture.height)
    s.render_texture(sample_texture, 0, 0,
                     :scale_x => scale_x,
                     :scale_y => scale_y)
  end

  @@slides << Slide.new(%Q{
!透視変換 API はちょっと複雑

@code_start
screen.render_in_perspective(
  texture,
  :camera_x => 320 :camera_y => 240,
  :camera_height => 500,
  :camera_yaw => 45.degrees,
  ...
  :intersection_x => 320,
  :intersection_y => 200,
  :loop => false)
@code_end
})

  @@slides << Slide.new(%Q{
!描画の概念が単純

なにもかも「テクスチャ」

* 画面
* PNG 画像
* 中間バッファ

「テクスチャからテクスチャに描く」を
繰り返すだけでなんでもできる
})

  @@slides << Slide.new(%Q{
!描画の疑似コード

画面に画像 image を描画する
@code_start
@color Color.new(0xcc, 0xcc, 0x99)
  画面.render_texture(image, ...)
@color back
@code_end

バッファ a にバッファ b を描画する
@code_start
@color Color.new(0xcc, 0xcc, 0x99)
  a.render_texture(b, ...)
@color back
@code_end

画面の複製
@code_start
@color Color.new(0xcc, 0xcc, 0x99)
  s = 画面.dup
@color back
@code_end
})

  soar_texture = Texture.load("images/soar")
  @@slides << Slide.new(%Q{
!実績 (1)

zebla さん
SOAR
}, :vx => -192) do |s|
    x = (s.width - soar_texture.width) - 64
    y = s.height - soar_texture.height - 54
    s.render_texture(soar_texture, x, y)
  end

  starlife_texture = Texture.load("images/starlife")
  @@slides << Slide.new(%Q{
!実績 (2)

gan2 さん
StarLife
}, :vx => -240) do |s|
    x = (s.width - starlife_texture.width) - 32
    y = s.height - starlife_texture.height - 54
    s.render_texture(starlife_texture, x, y)
  end

  rogue_texture = Texture.load("images/sc2")
  @@slides << Slide.new(%Q{
!実績 (3)

だいごくん
ローグ風 RPG

}, :vx => -160) do |s|
    x = (s.width - rogue_texture.width) - 32
    y = s.height - rogue_texture.height - 54
    s.render_texture(rogue_texture, x, y,
                     :src_width => 319,
                     :src_height => 238)
  end

  sc3_texture = Texture.load("images/sc3")
  @@slides << Slide.new("") do |s|
    s.render_texture(sc3_texture, -2, 0,
                     :scale_x => 2,
                     :scale_y => 2,
                     :src_height => 238)
  end

  sc1_texture = Texture.load("images/sc1")
  @@slides << Slide.new("") do |s|
    s.render_texture(sc1_texture, 3, 0,
                     :scale_x => 2,
                     :scale_y => 2,
                     :src_width => 318,
                     :src_height => 238)
  end

  @@slides << Slide.new(%Q{
!デモ

「Ruby が爆発するゲーム」
})

  rbg = RubyBusterGame.new
  @@slides << Slide.new("") do |s|
    rbg.update(s)
  end

  @@slides << Slide.new(%Q{
!開発者

* 星一 (プログラマー)
* 佐藤大悟 (文句言う人)

!!　　　　　　　　　　　　　　
})

  @@slides << Slide.new(%Q{
!開発者

* 星一 (プログラマー)
* 佐藤大悟 (文句言う人)

!!「だいごの文句ドリブン開発」
})

  @@slides << Slide.new(%Q{
!あと細かいこと

* 音楽は ogg などが鳴らせる
* 入力はキーボード、マウス、ゲームパッドなど
* Windows、Linux、 Mac OS X で動く
})

  @@slides << Slide.new(%Q{
!今後どうするか

* チュートリアルが足りないのでなんとかする
* ドキュメントが足りないのでなんとかする
})

  @@slides << Slide.new(%Q{
!まとめ

* Star Ruby でとっても簡単に
  楽しくゲームが作れます

@code_start
_http://www.starruby.info/
@code_end
})

  @@slides << Slide.new(%Q{
!!!自作ゲームライブラリ
!!!Star Ruby
!!!終わり
}, :centering => true)


  @@slides << Slide.new(%Q{
!最後に言いたいこと

!!!Ruby でゲームを作ろう!
}, :centering => true)

  @@slides << Slide.new(%Q{
!ご清聴ありがとうございました
}, :centering => true)

end

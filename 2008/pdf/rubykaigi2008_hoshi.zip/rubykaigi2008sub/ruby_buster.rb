require "starruby"
require "ruby_buster/controller"
require "ruby_buster/model"
require "ruby_buster/view"

class RubyBusterGame

  def initialize
    model      = RubyBuster::Model.new
    @controller = RubyBuster::Controller.new(model)
    @view       = RubyBuster::View.new(model)
  end

  def update(screen)
    @controller.update
    @view.update(screen)
  end

end

if $0 == __FILE__

  rbg = RubyBusterGame.new

  StarRuby::Game.run(640, 480, :cursor => true) do
    rbg.update(StarRuby::Game.screen)
  end

end

require "slide"

class News

  include StarRuby

  def initialize
    begin
      @rss = open("http://headlines.yahoo.co.jp/rss/c_int-yonh.xml") do |fp|
        RSS::Parser.parse(fp.read)
      end
    rescue
      @rss = nil
    end
    @x = 0
    @font = Slide.fonts[:small]
    if @rss
      @title_textures = @rss.items.map do |item|
        title = item.title
        size = @font.get_size(title)
        texture = Texture.new(*size)
        texture.render_text(title, 0, 0, @font, Color.new(0xff, 0xff, 0xcc), true)
        texture
      end
    end
  end

  def render_news_at(s)
    if @rss
      ox, oy = 0, s.height - 32
      s.render_rect(ox, oy, s.width, 32, Color.new(0x66, 0x66, 0x66, 128))
      @title_textures.inject(-@x + s.width) do |x, texture|
        s.render_texture(texture, ox + 4 + x, oy + 6)
        x + texture.width + 64
      end
    end
  end

  def update(s)
    if @rss
      @x += 2
      max_x = @title_textures.inject(0){|x, texture| x + texture.width + 64} + s.width
      @x = 0 if max_x < @x 
    end
  end

end
